import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
//import { ResumeAboutComponent } from './resume-about/resume-about.component';
import { ResumeLegaComponent } from './resume-lega/resume-lega.component';
//import { ResumeCounterComponent } from './resume-counter/resume-counter.component';
import { ResumeFooterComponent } from './resume-footer/resume-footer.component';
import { ResumeHeaderComponent } from './resume-header/resume-header.component';
import { ResumeNavComponent } from './resume-nav/resume-nav.component';
//import { ResumePortfolioComponent } from './resume-portfolio/resume-portfolio.component';
//import { ResumePricingComponent } from './resume-pricing/resume-pricing.component';
//import { ResumeScheduleComponent } from './resume-schedule/resume-schedule.component';
//import { ResumeServicesComponent } from './resume-services/resume-services.component';
//import { ResumeSubscribeComponent } from './resume-subscribe/resume-subscribe.component';

@Component({
  selector: 'app-resume',
  imports:[ResumeLegaComponent, ResumeFooterComponent,ResumeHeaderComponent,ResumeNavComponent,
    
  ],
  templateUrl: './resume.component.html',
  styleUrls: ['./resume.component.scss']
})
export class ResumeComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private title: Title) { }

  ngOnInit() {

    this.title.setTitle(this.route.snapshot.data['title']);
  }

}
