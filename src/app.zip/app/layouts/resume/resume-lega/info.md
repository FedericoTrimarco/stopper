Serie Eccellenza 

https://dni-cdn.goalshouter.com/public/widgets/standings?baseUrl=https%3A%2F%2Fdni-cdn.goalshouter.com&competition=f2cb8622-61e4-4791-9bc4-0a6f9e16150b&season=5d03ac25-bf64-49f7-ae9f-d39d75b62e46&uuid=1787a2da-c8fc-4769-96ab-0b4b1927479c&teamLinkUrl=%2Fsport%2Fcalcio%2Fsquadra%2F%7B%7BteamShortName%7D%7D%2F&teamLinkPolicy=local


RAPID API (Transfermarkt)

headers: {
		'x-rapidapi-key': '94ed4b0529mshcb3677c819fbd4ap1259dajsn912a528b1ed0',
		'x-rapidapi-host': 'transfermarkt6.p.rapidapi.com'
	}
    
// chiamata dei gironi
https://transfermarkt6.p.rapidapi.com/competitions/clubs?id=it4a&domain=it (IT4A to IT4I)

// chiamata del dettaglio squadra
// id squadra + anno
https://transfermarkt6.p.rapidapi.com/clubs/squad?id=56330&seasonId=2024


