import { Routes } from '@angular/router';
import { ResumeComponent } from './resume/resume.component';

export const Layout: Routes = [
  {
    path: 'resume',
    component: ResumeComponent,
    data: {
      title: "Stopper, looking for champions"
    }
  },
]