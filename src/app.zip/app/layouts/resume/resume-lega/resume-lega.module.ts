import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResumeLegaComponent } from './resume-lega.component';
import { GironeDetailComponent } from './girone-detail/girone-detail.component';
import { ClubDetailComponent } from './club-detail/club-detail.component';
import { ResumeLegaRoutingModule } from './resume-lega-routing.module';

@NgModule({
  declarations: [
    ResumeLegaComponent,
    GironeDetailComponent,
    ClubDetailComponent
  ],
  imports: [
    CommonModule,
    ResumeLegaRoutingModule
  ]
})
export class ResumeLegaModule {}
